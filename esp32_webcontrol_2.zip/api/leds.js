let ledState = "off";

export default function handler(req, res) {
  if (req.method === "GET") {
    res.status(200).json({ led: ledState });
  } 
  else if (req.method === "POST") {
    const { state } = req.body;
    ledState = state === "on" ? "on" : "off";
    res.status(200).json({ led: ledState });
  } 
  else {
    res.status(405).json({ error: "Method not allowed" });
  }
}
